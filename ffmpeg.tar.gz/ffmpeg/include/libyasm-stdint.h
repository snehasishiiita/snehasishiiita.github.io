#ifndef _YASM_LIBYASM_STDINT_H
#define _YASM_LIBYASM_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "yasm 1.3.0"
/* generated using gcc -std=gnu99 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
